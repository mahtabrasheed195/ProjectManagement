﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.ViewModel
{
    public class PMSMeetingAttendeeVM
    {

        public int MeetingID { get; set; }


        [Display(Name = "Project ID")]
        public int ProjectID { get; set; }

        [Display(Name = "Project Name")]
        public string ProjectName { get; set; }

        [Display(Name = "Meeting Title")]
        public string MeetingTitle { get; set; }

        [Display(Name = "Meeting No")]
        public Nullable<int> MeetingNo { get; set; }

        [Display(Name = "Meeting Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> MeetingDate { get; set; }


        [Display(Name = "Other Attendees")]
        public string OtherAttendees { get; set; }

        [Display(Name = "Regrets Or Absentees")]
        public string RegretsOrAbsentees { get; set; }

        [Display(Name = "Copy For Info")]
        public string CopyForInfo { get; set; }

        [Display(Name = "Next Meeting")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> NextMeeting { get; set; }


        [Display(Name = "Agenda")]
        public string Agenda { get; set; }

        [Display(Name = "Venue")]
        public string Venue { get; set; }


        public Nullable<int> MeetingCreatedByID { get; set; }
        public string MeetingCreatedByUserName { get; set; }

        [Display(Name = "Meeting Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> MeetingCreationDate { get; set; }


        [Required]
        [Display(Name = "Attendee")]
        public int ProjectStaffID { get; set; }

        [Display(Name = "Remarks")]
        public string Remarks { get; set; }
        public Nullable<int> AttendeeCreatedByID { get; set; }
        public string AttendeeCreatedByUserName { get; set; }

        [Display(Name = "Attendee Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> AttendeeCreationDate { get; set; }

        public ICollection<PMSMeetingAttendee> AddedAttendees { get; set; }

    }
}