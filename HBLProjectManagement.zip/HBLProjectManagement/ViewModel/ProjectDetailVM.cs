﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using HBLProjectManagement.Models;
using System.ComponentModel.DataAnnotations.Schema;

namespace HBLProjectManagement.ViewModel
{
    public class ProjectDetailVM
    {
        public int ProjectID { get; set; }
        public int AssignedProjectID { get; set; }
        
        [Display(Name = "Project Name")]
        public string ProjectName { get; set; }
        
        [Display(Name = "Project Description")]
        public string ProjectDescription { get; set; }

        [Display(Name = "Projet Start Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ProjectStartDate { get; set; }

        [Display(Name = "Project End Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ExpectedCompletionDate { get; set; }
        [Display(Name = "Expected Duration Years")]
        public Nullable<double> ExpectedDurationYears { get; set; }
        public bool Active { get; set; }

        [Display(Name = "Status")]
        public string StatusCode { get; set; }
        public Nullable<int> CreatedByID { get; set; }

        [Display(Name = "Creation By")]
        public string CreatedByUserName { get; set; }

        [Display(Name = "Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> CreationDate { get; set; }

        public Nullable<int> ProgramManagerID { get; set; }
        public Nullable<int> ProgramManagerDepartmentID { get; set; }

        [Display(Name = "Department")]
        public int DepartmentID { get; set; }

        public ICollection<PMSProjectStaff> AddedStaff { get; set; }
        public ICollection<PMSMeetingMinute> AddedMeetingMinute { get; set; }
        public ICollection<PMSProjectPlanWB> AddedProjectPlanWB { get; set; }
        public ICollection<PMSPlanCategory> AddedPlanCategory { get; set; }
        


    }
}