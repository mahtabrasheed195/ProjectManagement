﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.ViewModel
{
    public class ProjectCatVM
    {

        public int ProjectID { get; set; }
        public int AssignedProjectID { get; set; }

        [Display(Name = "Project Name")]
        public string ProjectName { get; set; }

        [Display(Name = "Project Description")]
        public string ProjectDescription { get; set; }

        [Display(Name = "Projet Start Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ProjectStartDate { get; set; }

        [Display(Name = "Project End Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ExpectedCompletionDate { get; set; }
        [Display(Name = "Expected Duration Years")]
        public Nullable<double> ExpectedDurationYears { get; set; }
        public bool Active { get; set; }

        public string StatusCode { get; set; }
        public Nullable<int> CreatedByID { get; set; }
        public string CreatedByUserName { get; set; }

        [Display(Name = "Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> CreationDate { get; set; }

        public Nullable<int> ProgramManagerID { get; set; }
        public Nullable<int> ProgramManagerDepartmentID { get; set; }

        public ICollection<PMSProjectStaff> AddedStaff { get; set; }

        public ICollection<PMSPlanCategory> AddedCategories { get; set; }

        public int PlanCategoryID { get; set; }


        [Display(Name = "Number of Days")]
        public int NumberofDays { get; set; }

        [Display(Name = "Start Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yy}")]
        public DateTime StartDate { get; set; }
        [Display(Name = "End Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yy}")]
        public DateTime EndDate { get; set; }


        [Required]
        [Display(Name = "Category Name")]
        public string PlanCategoryName { get; set; }
        [Required]
        [Display(Name = "Category Description")]
        public string PlanCategoryDescription { get; set; }
        public Nullable<int> CatCreatedByID { get; set; }
        [Display(Name = "Creation Date")]
        public string CatCreatedByUserName { get; set; }
        [Display(Name = "Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> CatCreationDate { get; set; }
        public Nullable<int> UpdateByID { get; set; }
        public string UpdatedByUserName { get; set; }
        public Nullable<System.DateTime> UpdateDate { get; set; }

    }
}