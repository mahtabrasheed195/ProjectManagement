﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.ViewModel
{
    public class ProjectTeamVM
    {
        public int ProjectID { get; set; }
        public int AssignedProjectID { get; set; }
        
        [Display(Name = "Project Name")]
        public string ProjectName { get; set; }
        
        [Display(Name = "Project Description")]
        public string ProjectDescription { get; set; }

        [Display(Name = "Projet Start Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ProjectStartDate { get; set; }

        [Display(Name = "Project End Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ExpectedCompletionDate { get; set; }
        [Display(Name = "Expected Duration Years")]
        public Nullable<double> ExpectedDurationYears { get; set; }
        public bool Active { get; set; }

        public string StatusCode { get; set; }
        public Nullable<int> CreatedByID { get; set; }
        public string CreatedByUserName { get; set; }

        [Display(Name = "Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> CreationDate { get; set; }

        public Nullable<int> ProgramManagerID { get; set; }
        public Nullable<int> ProgramManagerDepartmentID { get; set; }


        public int DepartmentID { get; set; }
        [Required]
        [Display(Name = "Staff Name")]
        public string StaffName { get; set; }
        [Required]
        [Display(Name = "Employee Number")]
        public string PNumber { get; set; }
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }

        public string Designation { get; set; }
        [Required]
        [Display(Name = "Role in Project")]
        public int RoleInProject { get; set; }
        [Display(Name = "Responsibility For Project")]
        public string ResponsibilityForProject { get; set; }
        public Nullable<int> StaffCreatedByID { get; set; }
        public string StaffCreatedByUserName { get; set; }
        [Display(Name = "Staff Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> StaffCreationDate { get; set; }

        public ICollection<PMSProjectStaff> AddedStaff { get; set; }


    }
}