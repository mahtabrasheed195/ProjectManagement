﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.ViewModel
{
    public class ProjectWBSVM : IValidatableObject
    {

        public int ProjectID { get; set; }
        public int AssignedProjectID { get; set; }

        [Display(Name = "Project Name")]
        public string ProjectName { get; set; }

        [Display(Name = "Project Description")]
        public string ProjectDescription { get; set; }

        [Display(Name = "Projet Start Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ProjectStartDate { get; set; }

        [Display(Name = "Project End Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ExpectedCompletionDate { get; set; }
        [Display(Name = "Expected Duration Years")]
        public Nullable<double> ExpectedDurationYears { get; set; }
        public bool Active { get; set; }

        public string StatusCode { get; set; }
        public Nullable<int> CreatedByID { get; set; }
        public string CreatedByUserName { get; set; }

        [Display(Name = "Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> CreationDate { get; set; }

        public Nullable<int> ProgramManagerID { get; set; }
        public Nullable<int> ProgramManagerDepartmentID { get; set; }

        public ICollection<PMSProjectStaff> AddedStaff { get; set; }
        public ICollection<PMSProjectPlanWB> AddedWBS { get; set; }
        public ICollection<PMSPlanCategory> AddedCategories { get; set; }


        [Required]
        [Display(Name = "Plan Category")]
        public int PlanCategoryID { get; set; }
        
        [Display(Name = "Serial Number")]
        public Nullable<int> SerialNumber { get; set; }
        //[Required]
        [Display(Name = "Status")]
        public string WBSStatusCode { get; set; }
        [Display(Name = "Remarks")]
        public string WBSStatusUpdateRemarks { get; set; }

        public int ProjectPlanWBSID { get; set; }
        [Required]
        [Display(Name = "Start Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> StartDate { get; set; }

        [Required]
        [Display(Name = "End Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
        [DataType(DataType.Date)]
        
        public Nullable<System.DateTime> EndDate { get; set; }


        IEnumerable<ValidationResult> IValidatableObject.Validate(ValidationContext validationContext)
        {
            if (EndDate < StartDate)
            {
                yield return new ValidationResult("End Date must be greater than Start Date");
            }
        }

        [Display(Name = "Duration Days")]
        public Nullable<int> DurationInDays { get; set; }
        [Required]
        [Display(Name = "Description")]
        public string Description { get; set; }
        [Required]
        [Display(Name = "Responsible Staff")]
        public Nullable<int> ResponsibleStaffID { get; set; }

        public Nullable<int> WBSCreatedByID { get; set; }
        public string WBSCreatedByUserName { get; set; }
        [Display(Name = "Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy-MM-dd}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> WBSCreationDate { get; set; }

        public Nullable<int> WBSUpdateByID { get; set; }
        public string WBSUpdatedByUserName { get; set; }
        public Nullable<System.DateTime> WBSUpdateDate { get; set; }

        [Display(Name = "Predecessor")]
        public Nullable<int> Predecessor { get; set; }




    }
}