﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.ViewModel
{
    public class ProjectMeetingMinuteVM
    {
        public int ProjectID { get; set; }
        public int AssignedProjectID { get; set; }
        
        [Display(Name = "Project Name")]
        public string ProjectName { get; set; }
        
        [Display(Name = "Project Description")]
        public string ProjectDescription { get; set; }

        [Display(Name = "Projet Start Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ProjectStartDate { get; set; }

        [Display(Name = "Project End Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ExpectedCompletionDate { get; set; }
        [Display(Name = "Expected Duration Years")]
        public Nullable<double> ExpectedDurationYears { get; set; }
        public bool Active { get; set; }

        public string StatusCode { get; set; }
        public Nullable<int> CreatedByID { get; set; }
        public string CreatedByUserName { get; set; }

        [Display(Name = "Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> CreationDate { get; set; }

        public Nullable<int> ProgramManagerID { get; set; }
        public Nullable<int> ProgramManagerDepartmentID { get; set; }

        [Required]
        [Display(Name = "Meeting Title")]
        public string MeetingTitle { get; set; }

        [Required]
        [Display(Name = "Meeting No")]
        public Nullable<int> MeetingNo { get; set; }

        [Required]
        [Display(Name = "MeetingDate")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> MeetingDate { get; set; }


        [Required]
        [Display(Name = "Other Attendees")]
        public string OtherAttendees { get; set; }

        [Required]
        [Display(Name = "Regrets Or Absentees")]
        public string RegretsOrAbsentees { get; set; }

        [Required]
        [Display(Name = "Copy For Info")]
        public string CopyForInfo { get; set; }

        [Required]
        [Display(Name = "Next Meeting")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> NextMeeting { get; set; }


        [Required]
        [Display(Name = "Agenda")]
        public string Agenda { get; set; }

        [Required]
        [Display(Name = "Venue")]
        public string Venue { get; set; }


        public Nullable<int> MeetingCreatedByID { get; set; }
        public string MeetingCreatedByUserName { get; set; }

        [Display(Name = "Meeting Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> MeetingCreationDate { get; set; }

        public ICollection<PMSMeetingMinute> AddedMeetings { get; set; }


    }
}