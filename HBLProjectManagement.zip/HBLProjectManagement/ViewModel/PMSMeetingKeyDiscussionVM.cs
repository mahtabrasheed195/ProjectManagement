﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.ViewModel
{
    public class PMSMeetingKeyDiscussionVM
    {

        public int MeetingID { get; set; }


        [Display(Name = "Project ID")]
        public int ProjectID { get; set; }

        [Display(Name = "Project Name")]
        public string ProjectName { get; set; }

        [Display(Name = "Meeting Title")]
        public string MeetingTitle { get; set; }

        [Display(Name = "Meeting No")]
        public Nullable<int> MeetingNo { get; set; }

        [Display(Name = "Meeting Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> MeetingDate { get; set; }


        [Display(Name = "Other Attendees")]
        public string OtherAttendees { get; set; }

        [Display(Name = "Regrets Or Absentees")]
        public string RegretsOrAbsentees { get; set; }

        [Display(Name = "Copy For Info")]
        public string CopyForInfo { get; set; }

        [Display(Name = "Next Meeting")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> NextMeeting { get; set; }


        [Display(Name = "Agenda")]
        public string Agenda { get; set; }

        [Display(Name = "Venue")]
        public string Venue { get; set; }


        public Nullable<int> MeetingCreatedByID { get; set; }
        public string MeetingCreatedByUserName { get; set; }

        [Display(Name = "Meeting Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> MeetingCreationDate { get; set; }


        [Required]
        [Display(Name = "Topic")]
        public string Topic { get; set; }
        [Required]
        [Display(Name = "Discussion")]
        public string Discussion { get; set; }
        [Required]
        [Display(Name = "Target Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> TargetDate { get; set; }
        [Required]
        [Display(Name = "Responsibility")]
        public Nullable<int> ResponsibilityOfStaff { get; set; }
        public Nullable<int> DiscussionCreatedByID { get; set; }
        public string DiscussionCreatedByUserName { get; set; }

        [Display(Name = "Discussion Creation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        [DataType(DataType.Date)]
        public Nullable<System.DateTime> DiscussionCreationDate { get; set; }

        public ICollection<PMSMeetingKeyDiscussion> AddedKeyDiscussions { get; set; }

    }
}