﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HBLProjectManagement.Models;
using HBLProjectManagement.Helpers;
using HBLProjectManagement.ViewModel;

namespace HBLProjectManagement.Controllers
{
    public class PMSProjectsController : Controller
    {
        private ProjectManagementSystemEntities db = new ProjectManagementSystemEntities();

        // GET: PMSProjects
        public ActionResult Index()
        {
            return View(db.PMSProjects.Where(w=>w.CreatedByUserName==User.Identity.Name)  .ToList());
        }

        // GET: PMSProjects/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProject pMSProject = db.PMSProjects.Find(id);
            if (pMSProject == null)
            {
                return HttpNotFound();
            }
            return View(pMSProject);
        }

        // GET: PMSProjects/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PMSProjects/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProjectID,ProjectName,ProjectDescription,ProjectStartDate,ExpectedCompletionDate,ExpectedDurationYears")] PMSProject pMSProject)
        {
            if (ModelState.IsValid)
            {
                pMSProject.CreatedByUserName = User.Identity.Name;
                pMSProject.CreationDate = DateTime.Now;
                pMSProject.StatusCode = "08";


                try
                {
                    db.PMSProjects.Add(pMSProject);
                    db.SaveChanges();
                }
                catch (Exception Exp)
                {
                    return View(pMSProject);
                }

                return RedirectToAction("ProjectInfo",new { id = pMSProject.ProjectID });
            }

            return View(pMSProject);
        }

        // GET: PMSProjects/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProject pMSProject = db.PMSProjects.Find(id);
            if (pMSProject == null)
            {
                return HttpNotFound();
            }
            return View(pMSProject);
        }

        // POST: PMSProjects/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProjectID,ProjectName,ProjectDescription,ProjectStartDate,ExpectedCompletionDate,ExpectedDurationYears,Active,OwnerID,OwnerDepartmentID,StatusCode,CreatedByID,CreatedByUserName,CreationDate")] PMSProject pMSProject)
        {
            if (ModelState.IsValid)
            {
                db.Entry(pMSProject).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(pMSProject);
        }

        // GET: PMSProjects/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProject pMSProject = db.PMSProjects.Find(id);
            if (pMSProject == null)
            {
                return HttpNotFound();
            }
            return View(pMSProject);
        }

        // POST: PMSProjects/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PMSProject pMSProject = db.PMSProjects.Find(id);
            db.PMSProjects.Remove(pMSProject);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        
        // GET: PMSProjects/Details/5
        public ActionResult ProjectInfo(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProject pMSProject = db.PMSProjects.Find(id);

           ProjectTeamVM vm=ProjectHelper.getProjectTeamVM(pMSProject);

            ViewBag.DepartmentID = new SelectList(db.PMSDepartments, "DepartmentID", "DepartmentName");
            ViewBag.RoleInProject = new SelectList(db.PMSProjectRoles, "ProjectRoleID", "ProjectRoleName");
            if (pMSProject == null)
            {
                return HttpNotFound();
            }
            return View(vm);
        }

        // POST: PMSProjects/Details/5 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProjectInfo([Bind(Exclude = "ProjectID")]ProjectTeamVM vm,int?id)
        {
            if (ModelState.IsValid)
            {
                if (vm == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                if (UserNameExist(vm.StaffName, id.Value))
                {
                    ModelState.AddModelError("StaffName", "Same Name Already Exist.");

                    PMSProject pMSProject1 = db.PMSProjects.Find(id.Value);

                    ProjectTeamVM rvm1 = ProjectHelper.getProjectTeamVM(pMSProject1);

                    ViewBag.DepartmentID = new SelectList(db.PMSDepartments, "DepartmentID", "DepartmentName");
                    ViewBag.RoleInProject = new SelectList(db.PMSProjectRoles, "ProjectRoleID", "ProjectRoleName");
                  

                    return View(rvm1);
                }
                vm.ProjectID = id.Value;
                vm.StaffCreatedByUserName = User.Identity.Name;
                vm.StaffCreationDate = DateTime.Now;

                PMSProjectStaff staff = ProjectHelper.getProjectStaff(vm);
                try
                {

                    db.PMSProjectStaffs.Add(staff);
                    db.SaveChanges();
                }
                catch (Exception Exp)
                {

                }

                PMSProject pMSProject = db.PMSProjects.Find(vm.ProjectID);

                ProjectTeamVM rvm = ProjectHelper.getProjectTeamVM(pMSProject);

                ViewBag.DepartmentID = new SelectList(db.PMSDepartments, "DepartmentID", "DepartmentName");
                ViewBag.RoleInProject = new SelectList(db.PMSProjectRoles, "ProjectRoleID", "ProjectRoleName");
                ViewBag.Message = "Team Member Added Successfully";
                if (rvm == null)
                {
                    return HttpNotFound();
                }
                ModelState.Clear();
                return View(rvm);
            }
            return View(vm);
        }

        // GET: PMSProjects/Details/5
        public ActionResult ProjectCategories(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProject pMSProject = db.PMSProjects.Find(id);

            ProjectCatVM vm = ProjectHelper.getProjectCategoriesVM(pMSProject);

            //ViewBag.DepartmentID = new SelectList(db.PMSDepartments, "DepartmentID", "DepartmentName");
            //ViewBag.RoleInProject = new SelectList(db.PMSProjectRoles, "ProjectRoleID", "ProjectRoleName");
            if (pMSProject == null)
            {
                return HttpNotFound();
            }
            return View(vm);
        }

        // POST: PMSProjects/Details/5 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProjectCategories(ProjectCatVM vm, int? id)
        {
            if (ModelState.IsValid)
            {
                if (vm == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }


                vm.ProjectID = id.Value;
                vm.CatCreatedByUserName = User.Identity.Name;
                vm.CatCreationDate = DateTime.Now;

                PMSPlanCategory cat = ProjectHelper.getProjectCategory(vm);
                try
                {

                    db.PMSPlanCategories.Add(cat);
                    db.SaveChanges();
                }
                catch (Exception Exp)
                {

                }

                PMSProject pMSProject = db.PMSProjects.Find(vm.ProjectID);

                ProjectCatVM rvm = ProjectHelper.getProjectCategoriesVM(pMSProject);

                //ViewBag.DepartmentID = new SelectList(db.PMSDepartments, "DepartmentID", "DepartmentName");
                //ViewBag.RoleInProject = new SelectList(db.PMSProjectRoles, "ProjectRoleID", "ProjectRoleName");
                if (rvm == null)
                {
                    return HttpNotFound();
                }
                return View(rvm);
            }
            return View(vm);
        }


        // GET: PMSProjects/Details/5
        public ActionResult ProjectPlanWBS(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProject pMSProject = db.PMSProjects.Find(id);

            ProjectWBSVM vm = ProjectHelper.getProjectWBSVM(pMSProject);

            int snumber = db.PMSProjectPlanWBS.Where(s => s.ProjectID == id).Count();

            snumber = snumber + 1;
            vm.SerialNumber = snumber;

            ViewBag.PlanCategoryID = new SelectList(db.PMSPlanCategories.Where(w=>w.ProjectID==pMSProject.ProjectID), "PlanCategoryID", "PlanCategoryName");
            //ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName");
            ViewBag.ResponsibleStaffID = new SelectList(db.PMSProjectStaffs.Where(w => w.ProjectID == pMSProject.ProjectID), "ProjectStaffID", "StaffName");
            ViewBag.StatusCode = new SelectList(db.PMSStatus, "WBSStatusCode", "StatusName");
            ViewBag.Predecessor = new SelectList(db.PMSProjectPlanWBS.Where(w => w.ProjectID == pMSProject.ProjectID), "SerialNumber", "SerialNumber");

            
            if (pMSProject == null)
            {
                return HttpNotFound();
            }
            return View(vm);
        }

        // POST: PMSProjects/Details/5 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProjectPlanWBS(ProjectWBSVM vm, int? id)
        {
            if (ModelState.IsValid)
            {
                if (vm == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }


                vm.ProjectID = id.Value;
                vm.WBSCreatedByUserName = User.Identity.Name;
                vm.WBSCreationDate = DateTime.Now;
                vm.WBSStatusCode = "08";

                int snumber = db.PMSProjectPlanWBS.Where(s => s.ProjectID == id).Count();

                snumber = snumber + 1;
                vm.SerialNumber = snumber;



                try
                {

                    DateTime ph = new DateTime(2018,01,01);

                    int duration = ProjectHelper.BusinessDaysUntil(vm.StartDate.Value, vm.EndDate.Value, ph);

                    vm.DurationInDays = duration;
                }
                catch (Exception Exp)
                {

                }


                PMSProjectPlanWB wbs = ProjectHelper.getProjectWBS(vm);
                try
                {

                    db.PMSProjectPlanWBS.Add(wbs);
                    db.SaveChanges();
                }
                catch (Exception Exp)
                {
                    return View(vm);
                }

                PMSProject pMSProject = db.PMSProjects.Find(vm.ProjectID);

                ProjectWBSVM rvm = ProjectHelper.getProjectWBSVM(pMSProject);

                ViewBag.PlanCategoryID = new SelectList(db.PMSPlanCategories, "PlanCategoryID", "PlanCategoryName");
                //ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName");
                ViewBag.ResponsibleStaffID = new SelectList(db.PMSProjectStaffs, "ProjectStaffID", "StaffName");
                //ViewBag.StatusCode = new SelectList(db.PMSStatus, "StatusCode", "StatusName");

                ViewBag.StatusCode = new SelectList(db.PMSStatus, "WBSStatusCode", "StatusName");
                ViewBag.Predecessor = new SelectList(db.PMSProjectPlanWBS.Where(w => w.ProjectID == pMSProject.ProjectID), "SerialNumber", "SerialNumber");


                if (rvm == null)
                {
                    return HttpNotFound();
                }
                ModelState.Clear();
                return View(rvm);
            }
            {
                PMSProject pMSProject = db.PMSProjects.Find(id.Value);

                ProjectWBSVM rvm = ProjectHelper.getProjectWBSVM(pMSProject);

                ViewBag.PlanCategoryID = new SelectList(db.PMSPlanCategories, "PlanCategoryID", "PlanCategoryName");
                //ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName");
                ViewBag.ResponsibleStaffID = new SelectList(db.PMSProjectStaffs, "ProjectStaffID", "StaffName");
                //ViewBag.StatusCode = new SelectList(db.PMSStatus, "StatusCode", "StatusName");
                ViewBag.StatusCode = new SelectList(db.PMSStatus, "WBSStatusCode", "StatusName");
                ViewBag.Predecessor = new SelectList(db.PMSProjectPlanWBS.Where(w => w.ProjectID == pMSProject.ProjectID), "SerialNumber", "SerialNumber");
                return View(rvm);
            }
        }


        // GET: PMSProjects/Details/5
        public ActionResult ProjectPlanWBSUpdate(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            PMSProjectPlanWB wbs = db.PMSProjectPlanWBS.Find(id);
            if (wbs == null)
            {
                return HttpNotFound();
            }
            //PMSProject pMSProject = db.PMSProjects.Find(wbs.ProjectID);

            ProjectWBSVM vm = ProjectHelper.getProjectWBSVMForEdit(wbs);

            //int snumber = db.PMSProjectPlanWBS.Where(s => s.ProjectID == id).Count();

            //snumber = snumber + 1;
            //vm.SerialNumber = snumber;

            ViewBag.PlanCategoryID = new SelectList(db.PMSPlanCategories.Where(w=>w.ProjectID==wbs.ProjectID), "PlanCategoryID", "PlanCategoryName",vm.PlanCategoryID);
            //ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName");
            ViewBag.ResponsibleStaffID = new SelectList(db.PMSProjectStaffs.Where(w => w.ProjectID == wbs.ProjectID), "ProjectStaffID", "StaffName", vm.ResponsibleStaffID);
            ViewBag.WBSStatusCode = new SelectList(db.PMSStatus,"StatusCode", "StatusName");
            ViewBag.Predecessor = new SelectList(db.PMSProjectPlanWBS.Where(w => w.ProjectID == wbs.ProjectID), "SerialNumber", "SerialNumber",vm.Predecessor);

            return View(vm);
        }

        // POST: PMSProjects/Details/5 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProjectPlanWBSUpdate(ProjectWBSVM vm, int? id)
        {
            if (ModelState.IsValid)
            {
                if (vm == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }


                vm.ProjectPlanWBSID = id.Value;
                vm.WBSUpdatedByUserName = User.Identity.Name;
                vm.WBSUpdateDate = DateTime.Now;


                //try
                //{

                //    DateTime ph = new DateTime(2018, 01, 01);

                //    int duration = ProjectHelper.BusinessDaysUntil(vm.StartDate.Value, vm.EndDate.Value, ph);

                //    vm.DurationInDays = duration;
                //}
                //catch (Exception Exp)
                //{
                //    ViewBag.Message = "Errors Occured.";
                //    return View(vm);
                //}


                PMSProjectPlanWB wbs = ProjectHelper.getProjectWBSForEdit(vm);
                try
                {

                    db.Entry(wbs).State = EntityState.Modified;
                    db.SaveChanges();
                }
                catch (Exception Exp)
                {
                    return View(vm);
                }

                PMSProject pMSProject = db.PMSProjects.Find(wbs.ProjectID);

                ProjectWBSVM rvm = ProjectHelper.getProjectWBSVMForEdit(wbs);

                ViewBag.PlanCategoryID = new SelectList(db.PMSPlanCategories.Where(w => w.ProjectID == wbs.ProjectID), "PlanCategoryID", "PlanCategoryName", vm.PlanCategoryID);
                //ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName");
                ViewBag.ResponsibleStaffID = new SelectList(db.PMSProjectStaffs.Where(w => w.ProjectID == wbs.ProjectID), "ProjectStaffID", "StaffName", vm.ResponsibleStaffID);
                ViewBag.WBSStatusCode = new SelectList(db.PMSStatus, "StatusCode", "StatusName");
                ViewBag.Predecessor = new SelectList(db.PMSProjectPlanWBS.Where(w => w.ProjectID == wbs.ProjectID), "SerialNumber", "SerialNumber", vm.Predecessor);

                ViewBag.Message = "Plan Updated Successfully";

                if (rvm == null)
                {
                    return HttpNotFound();
                }
                ModelState.Clear();
                return View(rvm);
            }
            {
                PMSProjectPlanWB wbs = db.PMSProjectPlanWBS.Find(id);

                PMSProject pMSProject = db.PMSProjects.Find(wbs.ProjectID);

                ProjectWBSVM rvm = ProjectHelper.getProjectWBSVMForEdit(wbs);

                ViewBag.PlanCategoryID = new SelectList(db.PMSPlanCategories.Where(w => w.ProjectID == wbs.ProjectID), "PlanCategoryID", "PlanCategoryName", vm.PlanCategoryID);
                //ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName");
                ViewBag.ResponsibleStaffID = new SelectList(db.PMSProjectStaffs.Where(w => w.ProjectID == wbs.ProjectID), "ProjectStaffID", "StaffName", vm.ResponsibleStaffID);
                ViewBag.WBSStatusCode = new SelectList(db.PMSStatus, "StatusCode", "StatusName"); ;
                ViewBag.Predecessor = new SelectList(db.PMSProjectPlanWBS.Where(w => w.ProjectID == wbs.ProjectID), "SerialNumber", "SerialNumber",vm.Predecessor);
                return View(rvm);
            }
        }

        public bool UserNameExist(string username,int projectid)
        {
          int result=  db.PMSProjectStaffs.Where(w => (w.ProjectID == projectid && w.StaffName == username)).Count(); ;

            if(result>0)
                return true;
            else
                return false;
        }

        // GET: PMSProjects/Details/5
        public ActionResult ProjectDetail(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProject pMSProject = db.PMSProjects.Find(id);
            ProjectDetailVM vm = ProjectHelper.getProjectDetailVM(pMSProject);

            if (pMSProject == null)
            {
                return HttpNotFound();
            }
            return View(vm);
        }

        // GET: PMSProjects/Details/5
        public ActionResult ProjectPlanDetail(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProject pMSProject = db.PMSProjects.Find(id);
            ProjectDetailVM vm = ProjectHelper.getProjectDetailVM(pMSProject);

            if (pMSProject == null)
            {
                return HttpNotFound();
            }
            return View(vm);
        }
    }
}
