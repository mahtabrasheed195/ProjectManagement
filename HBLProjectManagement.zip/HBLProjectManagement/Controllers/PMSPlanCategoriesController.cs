﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.Controllers
{
    public class PMSPlanCategoriesController : Controller
    {
        private ProjectManagementSystemEntities db = new ProjectManagementSystemEntities();

        // GET: PMSPlanCategories
        public ActionResult Index(int? id)
        {
            if (id.HasValue)
            {
                var pMSPlanCategories = db.PMSPlanCategories.Where(w=>w.ProjectID==id.Value).Include(p => p.PMSProject);
                return View(pMSPlanCategories.ToList());
            }
            else
            {
                var pMSPlanCategories = db.PMSPlanCategories.Include(p => p.PMSProject);
                return View(pMSPlanCategories.ToList());
            }
        }

        // GET: PMSPlanCategories/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSPlanCategory pMSPlanCategory = db.PMSPlanCategories.Find(id);
            if (pMSPlanCategory == null)
            {
                return HttpNotFound();
            }
            return View(pMSPlanCategory);
        }

        // GET: PMSPlanCategories/Create
        public ActionResult Create()
        {
            ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName");
            return View();
        }

        // POST: PMSPlanCategories/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "PlanCategoryID,PlanCategoryName,PlanCategoryDescription,ProjectID,CreatedByID,CreatedByUserName,CreationDate,UpdateByID,UpdatedByUserName,UpdateDate")] PMSPlanCategory pMSPlanCategory)
        {
            if (ModelState.IsValid)
            {
                db.PMSPlanCategories.Add(pMSPlanCategory);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName", pMSPlanCategory.ProjectID);
            return View(pMSPlanCategory);
        }

        // GET: PMSPlanCategories/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSPlanCategory pMSPlanCategory = db.PMSPlanCategories.Find(id);
            if (pMSPlanCategory == null)
            {
                return HttpNotFound();
            }
            ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName", pMSPlanCategory.ProjectID);
            return View(pMSPlanCategory);
        }

        // POST: PMSPlanCategories/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "PlanCategoryID,PlanCategoryName,PlanCategoryDescription,ProjectID,CreatedByID,CreatedByUserName,CreationDate,UpdateByID,UpdatedByUserName,UpdateDate")] PMSPlanCategory pMSPlanCategory)
        {
            if (ModelState.IsValid)
            {
                db.Entry(pMSPlanCategory).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName", pMSPlanCategory.ProjectID);
            return View(pMSPlanCategory);
        }

        // GET: PMSPlanCategories/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSPlanCategory pMSPlanCategory = db.PMSPlanCategories.Find(id);
            if (pMSPlanCategory == null)
            {
                return HttpNotFound();
            }
            return View(pMSPlanCategory);
        }

        // POST: PMSPlanCategories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PMSPlanCategory pMSPlanCategory = db.PMSPlanCategories.Find(id);
            db.PMSPlanCategories.Remove(pMSPlanCategory);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
