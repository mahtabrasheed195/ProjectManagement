﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.Controllers
{
    public class PMSProjectStaffsController : Controller
    {
        private ProjectManagementSystemEntities db = new ProjectManagementSystemEntities();

        // GET: PMSProjectStaffs
        public ActionResult Index()
        {
            var pMSProjectStaffs = db.PMSProjectStaffs.Include(p => p.PMSDepartment).Include(p => p.PMSProjectPlanWBSResponsible).Include(p => p.PMSProject);
            return View(pMSProjectStaffs.ToList());
        }

        // GET: PMSProjectStaffs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProjectStaff pMSProjectStaff = db.PMSProjectStaffs.Find(id);
            if (pMSProjectStaff == null)
            {
                return HttpNotFound();
            }
            return View(pMSProjectStaff);
        }

        // GET: PMSProjectStaffs/Create
        public ActionResult Create(int? id )
        {
            PMSProjectStaff staff = new PMSProjectStaff();
            //staff.ProjectID = id.Value;

            ViewBag.DepartmentID = new SelectList(db.PMSDepartments, "DepartmentID", "DepartmentName");
            //ViewBag.ProjectStaffID = new SelectList(db.PMSProjectPlanWBSResponsibles, "ProjectPlanWBSResponsibleID", "CreatedByUserName");
            //ViewBag.ProjectStaffID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName");
            return View(staff);
        }

        // POST: PMSProjectStaffs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProjectStaffID,ProjectID,DepartmentID,StaffName,PNumber,Email,Designation,RoleInProject,ResponsibilityForProject,CreatedByID,CreatedByUserName,CreationDate")] PMSProjectStaff pMSProjectStaff)
        {
            if (ModelState.IsValid)
            {
                db.PMSProjectStaffs.Add(pMSProjectStaff);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DepartmentID = new SelectList(db.PMSDepartments, "DepartmentID", "DepartmentName", pMSProjectStaff.ProjectStaffID);
            ViewBag.ProjectStaffID = new SelectList(db.PMSProjectPlanWBSResponsibles, "ProjectPlanWBSResponsibleID", "CreatedByUserName", pMSProjectStaff.ProjectStaffID);
            ViewBag.ProjectStaffID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName", pMSProjectStaff.ProjectStaffID);
            return View(pMSProjectStaff);
        }

        // GET: PMSProjectStaffs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProjectStaff pMSProjectStaff = db.PMSProjectStaffs.Find(id);
            if (pMSProjectStaff == null)
            {
                return HttpNotFound();
            }
            ViewBag.ProjectStaffID = new SelectList(db.PMSDepartments, "DepartmentID", "DepartmentName", pMSProjectStaff.ProjectStaffID);
            ViewBag.ProjectStaffID = new SelectList(db.PMSProjectPlanWBSResponsibles, "ProjectPlanWBSResponsibleID", "CreatedByUserName", pMSProjectStaff.ProjectStaffID);
            ViewBag.ProjectStaffID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName", pMSProjectStaff.ProjectStaffID);
            return View(pMSProjectStaff);
        }

        // POST: PMSProjectStaffs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProjectStaffID,ProjectID,DepartmentID,StaffName,PNumber,Email,Designation,RoleInProject,ResponsibilityForProject,CreatedByID,CreatedByUserName,CreationDate")] PMSProjectStaff pMSProjectStaff)
        {
            if (ModelState.IsValid)
            {
                db.Entry(pMSProjectStaff).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ProjectStaffID = new SelectList(db.PMSDepartments, "DepartmentID", "DepartmentName", pMSProjectStaff.ProjectStaffID);
            ViewBag.ProjectStaffID = new SelectList(db.PMSProjectPlanWBSResponsibles, "ProjectPlanWBSResponsibleID", "CreatedByUserName", pMSProjectStaff.ProjectStaffID);
            ViewBag.ProjectStaffID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName", pMSProjectStaff.ProjectStaffID);
            return View(pMSProjectStaff);
        }

        // GET: PMSProjectStaffs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProjectStaff pMSProjectStaff = db.PMSProjectStaffs.Find(id);
            if (pMSProjectStaff == null)
            {
                return HttpNotFound();
            }
            return View(pMSProjectStaff);
        }

        // POST: PMSProjectStaffs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PMSProjectStaff pMSProjectStaff = db.PMSProjectStaffs.Find(id);
            db.PMSProjectStaffs.Remove(pMSProjectStaff);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
