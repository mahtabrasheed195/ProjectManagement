﻿using HBLProjectManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HBLProjectManagement.Models;
using HBLProjectManagement.Helpers;
using HBLProjectManagement.ViewModel;
using System.Net;

namespace HBLProjectManagement.Controllers
{
    public class PMSMeetingMinuteController : Controller
    {
        private ProjectManagementSystemEntities db = new ProjectManagementSystemEntities();

        // GET: PMSMeetingMinute
        public ActionResult Index()
        {
            var pMSMeetingMinutes = db.PMSMeetingMinutes;
            return View(pMSMeetingMinutes.ToList());
        }

        // GET: PMSMeetingMinute/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: PMSMeetingMinute/Create
        public ActionResult Create()
        {
            PMSMeetingMinute meetingMinute = new PMSMeetingMinute();
            ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName");
            return View(meetingMinute);
        }

        // POST: PMSMeetingMinute/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: PMSMeetingMinute/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: PMSMeetingMinute/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: PMSMeetingMinute/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: PMSMeetingMinute/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


        public ActionResult ProjectMeetingMinute(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProject pMSProject = db.PMSProjects.Find(id);

            ProjectMeetingMinuteVM vm = ProjectHelper.getProjectMeetingMinuteVM(pMSProject);

            if (pMSProject == null)
            {
                return HttpNotFound();
            }
            return View(vm);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProjectMeetingMinute([Bind(Exclude = "ProjectID")]ProjectMeetingMinuteVM vm, int? id)
        {
            if (ModelState.IsValid)
            {
                if (vm == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }


                vm.ProjectID = id.Value;
                vm.MeetingCreatedByUserName = User.Identity.Name;
                vm.MeetingCreationDate = DateTime.Now;

                PMSMeetingMinute meetingMinute = ProjectHelper.getProjectMeetingMinute(vm);
                try
                {

                    db.PMSMeetingMinutes.Add(meetingMinute);
                    db.SaveChanges();
                }
                catch (Exception Exp)
                {

                }

                PMSProject pMSProject = db.PMSProjects.Find(vm.ProjectID);
                ProjectMeetingMinuteVM rvm = ProjectHelper.getProjectMeetingMinuteVM(pMSProject);

                //ProjectTeamVM rvm = ProjectHelper.getProjectTeamVM(pMSProject);

                if (rvm == null)
                {
                    return HttpNotFound();
                }
                return View(rvm);
            }
            PMSProject pMSProject1 = db.PMSProjects.Find(id);
            ProjectMeetingMinuteVM vm1 = ProjectHelper.getProjectMeetingMinuteVM(pMSProject1);
            return View(vm1);
        }
    }
}
