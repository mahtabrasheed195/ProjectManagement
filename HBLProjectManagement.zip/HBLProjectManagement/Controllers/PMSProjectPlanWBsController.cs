﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.Controllers
{
    public class PMSProjectPlanWBsController : Controller
    {
        private ProjectManagementSystemEntities db = new ProjectManagementSystemEntities();

        // GET: PMSProjectPlanWBs
        public ActionResult Index()
        {
            var pMSProjectPlanWBS = db.PMSProjectPlanWBS.Include(p => p.PMSPlanCategory).Include(p => p.PMSProject).Include(p => p.PMSProjectStaff).Include(p => p.PMSStatu);
            return View(pMSProjectPlanWBS.ToList());
        }

        // GET: PMSProjectPlanWBs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProjectPlanWB pMSProjectPlanWB = db.PMSProjectPlanWBS.Find(id);
            if (pMSProjectPlanWB == null)
            {
                return HttpNotFound();
            }
            return View(pMSProjectPlanWB);
        }

        // GET: PMSProjectPlanWBs/Create
        public ActionResult Create()
        {
            ViewBag.PlanCategoryID = new SelectList(db.PMSPlanCategories, "PlanCategoryID", "PlanCategoryName");
            ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName");
            ViewBag.ResponsibleStaffID = new SelectList(db.PMSProjectStaffs, "ProjectStaffID", "StaffName");
            ViewBag.StatusCode = new SelectList(db.PMSStatus, "StatusCode", "StatusName");
            return View();
        }

        // POST: PMSProjectPlanWBs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProjectPlanWBSID,ProjectID,PlanCategoryID,SerialNumber,StartDate,EndDate,DurationInDays,Description,ResponsibleStaffID,StatusCode,StatusUpdateRemarks,CreatedByID,CreatedByUserName,CreationDate,UpdateByID,UpdatedByUserName,UpdateDate")] PMSProjectPlanWB pMSProjectPlanWB)
        {
            if (ModelState.IsValid)
            {
                db.PMSProjectPlanWBS.Add(pMSProjectPlanWB);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.PlanCategoryID = new SelectList(db.PMSPlanCategories, "PlanCategoryID", "PlanCategoryName", pMSProjectPlanWB.PlanCategoryID);
            ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName", pMSProjectPlanWB.ProjectID);
            ViewBag.ResponsibleStaffID = new SelectList(db.PMSProjectStaffs, "ProjectStaffID", "StaffName", pMSProjectPlanWB.ResponsibleStaffID);
            ViewBag.StatusCode = new SelectList(db.PMSStatus, "StatusCode", "StatusName", pMSProjectPlanWB.StatusCode);
            return View(pMSProjectPlanWB);
        }

        // GET: PMSProjectPlanWBs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProjectPlanWB pMSProjectPlanWB = db.PMSProjectPlanWBS.Find(id);
            if (pMSProjectPlanWB == null)
            {
                return HttpNotFound();
            }
            ViewBag.PlanCategoryID = new SelectList(db.PMSPlanCategories, "PlanCategoryID", "PlanCategoryName", pMSProjectPlanWB.PlanCategoryID);
            ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName", pMSProjectPlanWB.ProjectID);
            ViewBag.ResponsibleStaffID = new SelectList(db.PMSProjectStaffs, "ProjectStaffID", "StaffName", pMSProjectPlanWB.ResponsibleStaffID);
            ViewBag.StatusCode = new SelectList(db.PMSStatus, "StatusCode", "StatusName", pMSProjectPlanWB.StatusCode);
            return View(pMSProjectPlanWB);
        }

        // POST: PMSProjectPlanWBs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProjectPlanWBSID,ProjectID,PlanCategoryID,SerialNumber,StartDate,EndDate,DurationInDays,Description,ResponsibleStaffID,StatusCode,StatusUpdateRemarks,CreatedByID,CreatedByUserName,CreationDate,UpdateByID,UpdatedByUserName,UpdateDate")] PMSProjectPlanWB pMSProjectPlanWB)
        {
            if (ModelState.IsValid)
            {
                db.Entry(pMSProjectPlanWB).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.PlanCategoryID = new SelectList(db.PMSPlanCategories, "PlanCategoryID", "PlanCategoryName", pMSProjectPlanWB.PlanCategoryID);
            ViewBag.ProjectID = new SelectList(db.PMSProjects, "ProjectID", "ProjectName", pMSProjectPlanWB.ProjectID);
            ViewBag.ResponsibleStaffID = new SelectList(db.PMSProjectStaffs, "ProjectStaffID", "StaffName", pMSProjectPlanWB.ResponsibleStaffID);
            ViewBag.StatusCode = new SelectList(db.PMSStatus, "StatusCode", "StatusName", pMSProjectPlanWB.StatusCode);
            return View(pMSProjectPlanWB);
        }

        // GET: PMSProjectPlanWBs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSProjectPlanWB pMSProjectPlanWB = db.PMSProjectPlanWBS.Find(id);
            if (pMSProjectPlanWB == null)
            {
                return HttpNotFound();
            }
            return View(pMSProjectPlanWB);
        }

        // POST: PMSProjectPlanWBs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PMSProjectPlanWB pMSProjectPlanWB = db.PMSProjectPlanWBS.Find(id);
            db.PMSProjectPlanWBS.Remove(pMSProjectPlanWB);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
