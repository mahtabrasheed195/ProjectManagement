﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HBLProjectManagement.Models;
using HBLProjectManagement.Helpers;
using HBLProjectManagement.ViewModel;
using System.Net;

namespace HBLProjectManagement.Controllers
{
    public class PMSMeetingKeyDiscussionController : Controller
    {
        private ProjectManagementSystemEntities db = new ProjectManagementSystemEntities();

        // GET: PMSMeetingKeyDiscussion
        public ActionResult Index()
        {
            return View();
        }

        // GET: PMSMeetingKeyDiscussion/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: PMSMeetingKeyDiscussion/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PMSMeetingKeyDiscussion/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: PMSMeetingKeyDiscussion/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: PMSMeetingKeyDiscussion/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: PMSMeetingKeyDiscussion/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: PMSMeetingKeyDiscussion/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }




        public ActionResult MeetingKeyDiscussion(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSMeetingMinute pMSMeetingMinute = db.PMSMeetingMinutes.Find(id);

            PMSMeetingKeyDiscussionVM vm = ProjectHelper.getPMSMeetingKeyDiscussionVM(pMSMeetingMinute);
            ViewBag.ResponsibilityOfStaff = new SelectList(db.PMSProjectStaffs.Where(x => x.ProjectID == pMSMeetingMinute.ProjectID), "ProjectStaffID", "StaffName");

            if (pMSMeetingMinute == null)
            {
                return HttpNotFound();
            }
            return View(vm);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult MeetingKeyDiscussion([Bind(Exclude = "MeetingID")]PMSMeetingKeyDiscussionVM vm, int? id)
        {
            if (ModelState.IsValid)
            {
                if (vm == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }


                vm.MeetingID = id.Value;
                vm.DiscussionCreatedByUserName = User.Identity.Name;
                vm.DiscussionCreationDate = DateTime.Now;

                PMSMeetingKeyDiscussion KeyDiscussion = ProjectHelper.getPMSMeetingKeyDiscussion(vm);
                try
                {

                    db.PMSMeetingKeyDiscussions.Add(KeyDiscussion);
                    db.SaveChanges();
                    ModelState.Clear();


                    PMSMeetingMinute meetingMinute = db.PMSMeetingMinutes.Find(vm.MeetingID);
                    PMSMeetingKeyDiscussionVM rvm = ProjectHelper.getPMSMeetingKeyDiscussionVM(meetingMinute);
                    ViewBag.ResponsibilityOfStaff = new SelectList(db.PMSProjectStaffs.Where(x => x.ProjectID == meetingMinute.ProjectID), "ProjectStaffID", "StaffName");


                    if (rvm == null)
                    {
                        return HttpNotFound();
                    }
                    return View(rvm);
                }
                catch (Exception Exp)
                {

                }
            }
            PMSMeetingMinute meetingMinute1 = db.PMSMeetingMinutes.Find(id);
            PMSMeetingKeyDiscussionVM rvm1 = ProjectHelper.getPMSMeetingKeyDiscussionVM(meetingMinute1);
            ViewBag.ResponsibilityOfStaff = new SelectList(db.PMSProjectStaffs.Where(x => x.ProjectID == meetingMinute1.ProjectID), "ProjectStaffID", "StaffName");

            return View(rvm1);
        }
    }
}
