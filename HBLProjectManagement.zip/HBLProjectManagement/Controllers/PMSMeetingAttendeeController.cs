﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HBLProjectManagement.Models;
using HBLProjectManagement.Helpers;
using HBLProjectManagement.ViewModel;
using System.Net;

namespace HBLProjectManagement.Controllers
{

    public class PMSMeetingAttendeeController : Controller
    {
        private ProjectManagementSystemEntities db = new ProjectManagementSystemEntities();

        // GET: PMSMeetingAttendee
        public ActionResult Index()
        {
            return View();
        }

        // GET: PMSMeetingAttendee/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: PMSMeetingAttendee/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PMSMeetingAttendee/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: PMSMeetingAttendee/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: PMSMeetingAttendee/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: PMSMeetingAttendee/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: PMSMeetingAttendee/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }



        public ActionResult MeetingAttendee(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PMSMeetingMinute pMSMeetingMinute = db.PMSMeetingMinutes.Find(id);

            PMSMeetingAttendeeVM vm = ProjectHelper.getPMSMeetingAttendeeVM(pMSMeetingMinute);

            if (pMSMeetingMinute == null)
            {
                return HttpNotFound();
            }
            ViewBag.ProjectStaffID = new SelectList(db.PMSProjectStaffs, "ProjectStaffID", "StaffName", vm.ProjectStaffID);

            return View(vm);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult MeetingAttendee([Bind(Exclude = "MeetingID")]PMSMeetingAttendeeVM vm, int? id)
        {
            if (ModelState.IsValid)
            {
                if (vm == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }


                vm.MeetingID = id.Value;
                vm.AttendeeCreatedByUserName = User.Identity.Name;
                vm.AttendeeCreationDate= DateTime.Now;

                PMSMeetingAttendee Attendee = ProjectHelper.getPMSMeetingAttendee(vm);
                try
                {

                    db.PMSMeetingAttendees.Add(Attendee);
                    db.SaveChanges();
                    ModelState.Clear();
                }
                catch (Exception Exp)
                {

                }

                PMSMeetingMinute meetingMinute = db.PMSMeetingMinutes.Find(vm.MeetingID);
                PMSMeetingAttendeeVM rvm = ProjectHelper.getPMSMeetingAttendeeVM(meetingMinute);


                if (rvm == null)
                {
                    return HttpNotFound();
                }
                ViewBag.ProjectStaffID = new SelectList(db.PMSProjectStaffs, "ProjectStaffID", "StaffName", vm.ProjectStaffID);

                return View(rvm);
            }
            PMSMeetingMinute meetingMinute1 = db.PMSMeetingMinutes.Find(id);
            PMSMeetingAttendeeVM rvm1 = ProjectHelper.getPMSMeetingAttendeeVM(meetingMinute1);
            ViewBag.ProjectStaffID = new SelectList(db.PMSProjectStaffs, "ProjectStaffID", "StaffName", vm.ProjectStaffID);

            return View(rvm1);
        }
    }
}
