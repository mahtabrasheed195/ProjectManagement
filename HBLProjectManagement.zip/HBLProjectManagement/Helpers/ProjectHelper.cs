﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HBLProjectManagement.ViewModel;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.Helpers
{
    public static class ProjectHelper
    {
        public static ProjectTeamVM getProjectTeamVM(PMSProject project)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                ProjectTeamVM vm = new ProjectTeamVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;
                vm.AddedStaff = entity.PMSProjectStaffs.Where(w => w.ProjectID == project.ProjectID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }


        public static PMSProjectStaff getProjectStaff(ProjectTeamVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSProjectStaff staff = new PMSProjectStaff();

                staff.CreatedByID = vm.StaffCreatedByID;
                staff.CreatedByUserName = vm.StaffCreatedByUserName;
                staff.CreationDate = vm.StaffCreationDate;
                staff.DepartmentID = vm.DepartmentID;
                staff.Designation = vm.Designation;
                staff.Email = vm.Email;
                staff.PNumber = vm.PNumber;
                staff.ProjectID = vm.ProjectID;
                staff.ResponsibilityForProject = vm.ResponsibilityForProject;
                staff.RoleInProject = vm.RoleInProject;
                staff.StaffName = vm.StaffName;

                return staff;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }


        public static ProjectCatVM getProjectCategoriesVM(PMSProject project)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                ProjectCatVM vm = new ProjectCatVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;
                vm.AddedCategories = entity.PMSPlanCategories.Where(w => w.ProjectID == project.ProjectID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

        public static PMSPlanCategory getProjectCategory(ProjectCatVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSPlanCategory cat = new PMSPlanCategory();

                cat.CreatedByID = vm.CatCreatedByID;
                cat.CreatedByUserName = vm.CatCreatedByUserName;
                cat.CreationDate = vm.CatCreationDate;
                cat.PlanCategoryDescription = vm.PlanCategoryDescription;
                cat.PlanCategoryName = vm.PlanCategoryName;
                cat.ProjectID = vm.ProjectID;
                cat.UpdateByID = vm.UpdateByID;
                cat.UpdateDate = vm.UpdateDate;
                cat.UpdatedByUserName = vm.UpdatedByUserName;


                return cat;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }


        public static ProjectWBSVM getProjectWBSVM(PMSProject project)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                ProjectWBSVM vm = new ProjectWBSVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;
                vm.AddedWBS = entity.PMSProjectPlanWBS.Where(w => w.ProjectID == project.ProjectID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

        public static PMSProjectPlanWB getProjectWBS(ProjectWBSVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSProjectPlanWB wbs = new PMSProjectPlanWB();

                wbs.CreatedByID = vm.WBSCreatedByID;
                wbs.CreatedByUserName = vm.WBSCreatedByUserName;
                wbs.CreationDate = vm.WBSCreationDate;
                wbs.Description = vm.Description;
                // TimeSpan diff= vm.EndDate.Value.Subtract(vm.StartDate.Value);
                wbs.DurationInDays = vm.DurationInDays; //diff.Days;
                wbs.EndDate = vm.EndDate;
                wbs.PlanCategoryID = vm.PlanCategoryID;
                wbs.ProjectID = vm.ProjectID;
                wbs.ResponsibleStaffID = vm.ResponsibleStaffID;
                wbs.SerialNumber = vm.SerialNumber;
                wbs.StartDate = vm.StartDate;
                wbs.StatusCode = vm.WBSStatusCode;
                wbs.StatusUpdateRemarks = vm.WBSStatusUpdateRemarks;


                return wbs;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

        public static ProjectMeetingMinuteVM getProjectMeetingMinuteVM(PMSProject project)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                ProjectMeetingMinuteVM vm = new ProjectMeetingMinuteVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;
                vm.AddedMeetings = entity.PMSMeetingMinutes.Where(w => w.ProjectID == project.ProjectID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }
        public static PMSMeetingMinute getProjectMeetingMinute(ProjectMeetingMinuteVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSMeetingMinute meetingMinute = new PMSMeetingMinute();

                meetingMinute.CreatedByID = vm.MeetingCreatedByID;
                meetingMinute.CreatedByUserName = vm.MeetingCreatedByUserName;
                meetingMinute.CreationDate = vm.MeetingCreationDate;
                meetingMinute.Agenda = vm.Agenda;
                meetingMinute.CopyForInfo = vm.CopyForInfo;
                meetingMinute.MeetingDate = vm.MeetingDate;
                meetingMinute.MeetingNo = vm.MeetingNo;
                meetingMinute.MeetingTitle = vm.MeetingTitle;
                meetingMinute.NextMeeting = vm.NextMeeting;
                meetingMinute.OtherAttendees = vm.OtherAttendees;
                meetingMinute.RegretsOrAbsentees = vm.RegretsOrAbsentees;
                meetingMinute.Venue = vm.Venue;
                meetingMinute.ProjectID = vm.ProjectID;

                return meetingMinute;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

        /// <summary>
        /// Calculates number of business days, taking into account:
        ///  - weekends (Saturdays and Sundays)
        ///  - bank holidays in the middle of the week
        /// </summary>
        /// <param name="firstDay">First day in the time interval</param>
        /// <param name="lastDay">Last day in the time interval</param>
        /// <param name="bankHolidays">List of bank holidays excluding weekends</param>
        /// <returns>Number of business days during the 'span'</returns>
        public static int BusinessDaysUntil(this DateTime firstDay, DateTime lastDay, params DateTime[] bankHolidays)
        {
            firstDay = firstDay.Date;
            lastDay = lastDay.Date;
            if (firstDay > lastDay)
                throw new ArgumentException("Incorrect last day " + lastDay);

            TimeSpan span = lastDay - firstDay;
            int businessDays = span.Days + 1;
            int fullWeekCount = businessDays / 7;
            // find out if there are weekends during the time exceedng the full weeks
            if (businessDays > fullWeekCount * 7)
            {
                // we are here to find out if there is a 1-day or 2-days weekend
                // in the time interval remaining after subtracting the complete weeks
                int firstDayOfWeek = (int)firstDay.DayOfWeek;
                int lastDayOfWeek = (int)lastDay.DayOfWeek;
                if (lastDayOfWeek < firstDayOfWeek)
                    lastDayOfWeek += 7;
                if (firstDayOfWeek <= 6)
                {
                    if (lastDayOfWeek >= 7)// Both Saturday and Sunday are in the remaining time interval
                        businessDays -= 2;
                    else if (lastDayOfWeek >= 6)// Only Saturday is in the remaining time interval
                        businessDays -= 1;
                }
                else if (firstDayOfWeek <= 7 && lastDayOfWeek >= 7)// Only Sunday is in the remaining time interval
                    businessDays -= 1;
            }

            // subtract the weekends during the full weeks in the interval
            businessDays -= fullWeekCount + fullWeekCount;

            // subtract the number of bank holidays during the time interval
            foreach (DateTime bankHoliday in bankHolidays)
            {
                DateTime bh = bankHoliday.Date;
                if (firstDay <= bh && bh <= lastDay)
                    --businessDays;
            }

            return businessDays;
        }
        public static PMSMeetingKeyDiscussion getPMSMeetingKeyDiscussion(PMSMeetingKeyDiscussionVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();


                PMSMeetingKeyDiscussion KeyDiscussion = new PMSMeetingKeyDiscussion();

                KeyDiscussion.MeetingID = vm.MeetingID;
                KeyDiscussion.Discussion = vm.Discussion;
                KeyDiscussion.ResponsibilityOfStaff = vm.ResponsibilityOfStaff;
                KeyDiscussion.TargetDate = vm.TargetDate;
                KeyDiscussion.Topic = vm.Topic;


                return KeyDiscussion;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }
        public static PMSMeetingKeyDiscussionVM getPMSMeetingKeyDiscussionVM(PMSMeetingMinute PMM)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSMeetingKeyDiscussionVM vm = new PMSMeetingKeyDiscussionVM();

                vm.ProjectID = PMM.PMSProject.ProjectID;
                vm.ProjectName = PMM.PMSProject.ProjectName;
                vm.Agenda = PMM.Agenda;
                vm.CopyForInfo = PMM.CopyForInfo;
                vm.MeetingCreatedByID = PMM.CreatedByID;
                vm.MeetingCreatedByUserName = PMM.CreatedByUserName;
                vm.MeetingCreationDate = PMM.CreationDate;
                vm.MeetingDate = PMM.MeetingDate;
                vm.MeetingID = PMM.MeetingID;
                vm.MeetingNo = PMM.MeetingNo;
                vm.MeetingTitle = PMM.MeetingTitle;
                vm.NextMeeting = PMM.NextMeeting;
                vm.OtherAttendees = PMM.OtherAttendees;
                vm.RegretsOrAbsentees = PMM.RegretsOrAbsentees;
                vm.Venue = PMM.Venue;

                vm.AddedKeyDiscussions = entity.PMSMeetingKeyDiscussions.Where(w => w.MeetingID == PMM.MeetingID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }


        public static ProjectWBSVM getProjectWBSVMForEdit(PMSProjectPlanWB wbs)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSProject project = entity.PMSProjects.Find(wbs.ProjectID);

                ProjectWBSVM vm = new ProjectWBSVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;
                vm.AddedWBS = entity.PMSProjectPlanWBS.Where(w => w.ProjectID == project.ProjectID).ToList();


                vm.WBSCreatedByID = wbs.CreatedByID;
                vm.WBSCreatedByUserName = wbs.CreatedByUserName;
                vm.WBSCreationDate = wbs.CreationDate;
                vm.Description = wbs.Description;
                // TimeSpan diff= wbs.EndDate.Value.Subtract(wbs.StartDate.Value);
                vm.DurationInDays = wbs.DurationInDays; //diff.Days;
                vm.EndDate = wbs.EndDate;
                vm.PlanCategoryID = wbs.PlanCategoryID;
                vm.ProjectID = wbs.ProjectID;
                vm.ResponsibleStaffID = wbs.ResponsibleStaffID;
                vm.SerialNumber = wbs.SerialNumber;
                vm.StartDate = wbs.StartDate;
                vm.WBSStatusCode = wbs.StatusCode;
                vm.WBSStatusUpdateRemarks = wbs.StatusUpdateRemarks;

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

        public static PMSProjectPlanWB getProjectWBSForEdit(ProjectWBSVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSProjectPlanWB wbs = new PMSProjectPlanWB();


                wbs.CreatedByID = vm.WBSCreatedByID;
                wbs.CreatedByUserName = vm.WBSCreatedByUserName;
                wbs.CreationDate = vm.WBSCreationDate;
                wbs.Description = vm.Description;
                // TimeSpan diff= vm.EndDate.Value.Subtract(vm.StartDate.Value);
                wbs.DurationInDays = vm.DurationInDays; //diff.Days;
                wbs.EndDate = vm.EndDate;
                wbs.PlanCategoryID = vm.PlanCategoryID;

                wbs.ResponsibleStaffID = vm.ResponsibleStaffID;
                wbs.SerialNumber = vm.SerialNumber;
                wbs.StartDate = vm.StartDate;
                wbs.StatusCode = vm.WBSStatusCode;
                wbs.StatusUpdateRemarks = vm.WBSStatusUpdateRemarks;
                wbs.UpdateByID = vm.WBSUpdateByID;
                wbs.UpdateDate = vm.WBSUpdateDate;
                wbs.UpdatedByUserName = vm.WBSUpdatedByUserName;

                wbs.ProjectPlanWBSID = vm.ProjectPlanWBSID;

                int projectID = entity.PMSProjectPlanWBS.Find(vm.ProjectPlanWBSID).ProjectID;

                wbs.ProjectID = projectID;

                var tempWBS = entity.PMSProjectPlanWBS.Find(vm.ProjectPlanWBSID);

                wbs.DurationInDays = tempWBS.DurationInDays;
                wbs.SerialNumber = tempWBS.SerialNumber;
                wbs.CreatedByID = tempWBS.CreatedByID;
                wbs.CreatedByUserName = tempWBS.CreatedByUserName;
                wbs.CreationDate = tempWBS.CreationDate;

                return wbs;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

        public static PMSMeetingAttendee getPMSMeetingAttendee(PMSMeetingAttendeeVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();


                PMSMeetingAttendee Attendee = new PMSMeetingAttendee();

                Attendee.MeetingID = vm.MeetingID;
                Attendee.ProjectStaffID = vm.ProjectStaffID;
                Attendee.Remarks = vm.Remarks;

                return Attendee;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }
        public static PMSMeetingAttendeeVM getPMSMeetingAttendeeVM(PMSMeetingMinute PMM)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSMeetingAttendeeVM vm = new PMSMeetingAttendeeVM();

                vm.ProjectID = PMM.PMSProject.ProjectID;
                vm.ProjectName = PMM.PMSProject.ProjectName;
                vm.Agenda = PMM.Agenda;
                vm.CopyForInfo = PMM.CopyForInfo;
                vm.MeetingCreatedByID = PMM.CreatedByID;
                vm.MeetingCreatedByUserName = PMM.CreatedByUserName;
                vm.MeetingCreationDate = PMM.CreationDate;
                vm.MeetingDate = PMM.MeetingDate;
                vm.MeetingID = PMM.MeetingID;
                vm.MeetingNo = PMM.MeetingNo;
                vm.MeetingTitle = PMM.MeetingTitle;
                vm.NextMeeting = PMM.NextMeeting;
                vm.OtherAttendees = PMM.OtherAttendees;
                vm.RegretsOrAbsentees = PMM.RegretsOrAbsentees;
                vm.Venue = PMM.Venue;

                vm.AddedAttendees = entity.PMSMeetingAttendees.Where(w => w.MeetingID == PMM.MeetingID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }


        public static ProjectMeetingDetailVM getProjectMeetingDetailVM(PMSProject project, PMSMeetingMinute pmm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                ProjectMeetingDetailVM vm = new ProjectMeetingDetailVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;

                vm.Agenda = pmm.Agenda;
                vm.CopyForInfo = pmm.CopyForInfo;
                vm.MeetingDate = pmm.MeetingDate;
                vm.MeetingNo = pmm.MeetingNo;
                vm.MeetingTitle = pmm.MeetingTitle;
                vm.NextMeeting = pmm.NextMeeting;
                vm.OtherAttendees = pmm.OtherAttendees;

                vm.AddedAttendee = entity.PMSMeetingAttendees.Where(w => w.MeetingID == pmm.MeetingID).ToList();
                vm.AddedKeyDiscussion = entity.PMSMeetingKeyDiscussions.Where(w => w.MeetingID == pmm.MeetingID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

        public static ProjectDetailVM getProjectDetailVM(PMSProject project)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                ProjectDetailVM vm = new ProjectDetailVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;
                vm.AddedStaff = entity.PMSProjectStaffs.Where(w => w.ProjectID == project.ProjectID).ToList();
                vm.AddedMeetingMinute = entity.PMSMeetingMinutes.Where(w => w.ProjectID == project.ProjectID).ToList();
                vm.AddedProjectPlanWB = entity.PMSProjectPlanWBS.Where(w => w.ProjectID == project.ProjectID).ToList();
                vm.AddedPlanCategory = entity.PMSPlanCategories.Where(w => w.ProjectID == project.ProjectID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

    }
}