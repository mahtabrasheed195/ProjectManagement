﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HBLProjectManagement.ViewModel;
using HBLProjectManagement.Models;

namespace HBLProjectManagement.Helpers
{
    public static class ProjectHelper
    {
        public static ProjectTeamVM getProjectTeamVM(PMSProject project)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                ProjectTeamVM vm = new ProjectTeamVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;
                vm.AddedStaff = entity.PMSProjectStaffs.Where(w => w.ProjectID == project.ProjectID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }


        public static PMSProjectStaff getProjectStaff(ProjectTeamVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSProjectStaff staff = new PMSProjectStaff();

                staff.CreatedByID = vm.StaffCreatedByID;
                staff.CreatedByUserName = vm.StaffCreatedByUserName;
                staff.CreationDate = vm.StaffCreationDate;
                staff.DepartmentID = vm.DepartmentID;
                staff.Designation = vm.Designation;
                staff.Email = vm.Email;
                staff.PNumber = vm.PNumber;
                staff.ProjectID = vm.ProjectID;
                staff.ResponsibilityForProject = vm.ResponsibilityForProject;
                staff.RoleInProject = vm.RoleInProject;
                staff.StaffName = vm.StaffName;

                return staff;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }


        public static ProjectCatVM getProjectCategoriesVM(PMSProject project)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                ProjectCatVM vm = new ProjectCatVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;
                vm.AddedCategories = entity.PMSPlanCategories.Where(w => w.ProjectID == project.ProjectID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

        public static PMSPlanCategory getProjectCategory(ProjectCatVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSPlanCategory cat = new PMSPlanCategory();

                cat.CreatedByID = vm.CatCreatedByID;
                cat.CreatedByUserName = vm.CatCreatedByUserName;
                cat.CreationDate = vm.CatCreationDate;
                cat.PlanCategoryDescription = vm.PlanCategoryDescription;
                cat.PlanCategoryName = vm.PlanCategoryName;
                cat.ProjectID = vm.ProjectID;
                cat.UpdateByID = vm.UpdateByID;
                cat.UpdateDate = vm.UpdateDate;
                cat.UpdatedByUserName = vm.UpdatedByUserName;
                

                return cat;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }


        public static ProjectWBSVM getProjectWBSVM(PMSProject project)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                ProjectWBSVM vm = new ProjectWBSVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;
                vm.AddedWBS = entity.PMSProjectPlanWBS.Where(w => w.ProjectID == project.ProjectID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

        public static PMSProjectPlanWB getProjectWBS(ProjectWBSVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSProjectPlanWB wbs = new PMSProjectPlanWB();

                wbs.CreatedByID = vm.WBSCreatedByID;
                wbs.CreatedByUserName = vm.WBSCreatedByUserName;
                wbs.CreationDate = vm.WBSCreationDate;
                wbs.Description = vm.Description;
                wbs.DurationInDays = vm.DurationInDays;
                wbs.EndDate = vm.EndDate;
                wbs.PlanCategoryID = vm.PlanCategoryID;
                wbs.ProjectID = vm.ProjectID;
                wbs.ResponsibleStaffID = vm.ResponsibleStaffID;
                wbs.SerialNumber = vm.SerialNumber;
                wbs.StartDate = vm.StartDate;
                wbs.StatusCode = vm.WBSStatusCode;
                wbs.StatusUpdateRemarks = vm.WBSStatusUpdateRemarks;


                return wbs;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

        public static ProjectMeetingMinuteVM getProjectMeetingMinuteVM(PMSProject project)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                ProjectMeetingMinuteVM vm = new ProjectMeetingMinuteVM();

                vm.Active = project.Active;
                vm.CreatedByID = project.CreatedByID;
                vm.CreatedByUserName = project.CreatedByUserName;
                vm.CreationDate = project.CreationDate;
                vm.ExpectedCompletionDate = project.ExpectedCompletionDate;
                vm.ExpectedDurationYears = project.ExpectedDurationYears;
                vm.ProgramManagerDepartmentID = project.ProgramManagerDepartmentID;
                vm.ProgramManagerID = project.ProgramManagerID;
                vm.ProjectDescription = project.ProjectDescription;
                vm.ProjectID = project.ProjectID;
                vm.ProjectName = project.ProjectName;
                vm.ProjectStartDate = project.ProjectStartDate;
                vm.StatusCode = project.StatusCode;
                vm.AssignedProjectID = project.ProjectID;
                vm.AddedMeetings = entity.PMSMeetingMinutes.Where(w => w.ProjectID == project.ProjectID).ToList();

                return vm;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }
        public static PMSMeetingMinute getProjectMeetingMinute(ProjectMeetingMinuteVM vm)
        {
            try
            {
                ProjectManagementSystemEntities entity = new ProjectManagementSystemEntities();

                PMSMeetingMinute meetingMinute = new PMSMeetingMinute();

                meetingMinute.CreatedByID = vm.MeetingCreatedByID;
                meetingMinute.CreatedByUserName = vm.MeetingCreatedByUserName;
                meetingMinute.CreationDate = vm.MeetingCreationDate;
                meetingMinute.Agenda = vm.Agenda;
                meetingMinute.CopyForInfo = vm.CopyForInfo;
                meetingMinute.MeetingDate = vm.MeetingDate;
                meetingMinute.MeetingNo = vm.MeetingNo;
                meetingMinute.MeetingTitle = vm.MeetingTitle;
                meetingMinute.NextMeeting = vm.NextMeeting;
                meetingMinute.OtherAttendees = vm.OtherAttendees;
                meetingMinute.RegretsOrAbsentees = vm.RegretsOrAbsentees;
                meetingMinute.Venue = vm.Venue;
                meetingMinute.ProjectID = vm.ProjectID;

                return meetingMinute;
            }
            catch (Exception Exp)
            {
                return null;
            }
        }

    }
}